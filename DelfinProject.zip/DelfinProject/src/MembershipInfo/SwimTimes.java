package MembershipInfo;

public class SwimTimes
{
    private double time;


}
